function [sys,x0,str,ts] = sfuntmpl(t,x,u,flag)
%SFUNTMPL General M-file S-function template
%   With M-file S-functions, you can define you own ordinary differential
%   equations (ODEs), discrete system equations, and/or just about
%   any type of algorithm to be used within a Simulink block diagram.
%
%   The general form of an M-File S-function syntax is:
%       [SYS,X0,STR,TS] = SFUNC(T,X,U,FLAG,P1,...,Pn)
%
%   What is returned by SFUNC at a given point in t         ime, T, depends on the
%   value of the FLAG, the current state vector, X, and the current
%   input vector, U.
%
%   FLAG   RESULT             DESCRIPTION
%   -----  ------             --------------------------------------------
%   0      [SIZES,X0,STR,TS]  Initialization, return system sizes in SYS,
%                             initial state in X0, state ordering strings
%                             in STR, and sample times in TS.
%   1      DX                   Return continuous state derivatives in SYS.
%   2      DS                 Update discrete states SYS = X(n+1)
%   3      Y                  Return outputs in SYS.
%   4      TNEXT              Return next time hit for variable step sample
%                             time in SYS.
%   5                         Reserved for future (root finding).
%   9      []                 Termination, perform any cleanup SYS=[].
%
%
%   The state vectors, X and X0 consists of continuous states followed
%   by discrete states.
%
%   Optional parameters, P1,...,Pn can be provided to the S-function and
%   used during any FLAG operation.
%
%   When SFUNC is called with FLAG = 0, the following information
%   should be returned:
%
%      SYS(1) = Number of continuous states.
%      SYS(2) = Number of discrete states.
%      SYS(3) = Number of outputs.
%      SYS(4) = Number of inputs.
%               Any of the first four elements in SYS can be specified
%               as -1 indicating that they are dynamically sized. The
%               actual length for all other flags will be equal to the
%               length of the input, U.
%      SYS(5) = Reserved for root finding. Must be zero.
%      SYS(6) = Direct feedthrough flag (1=yes, 0=no). The s-function
%               has direct feedthrough if U is used during the FLAG=3
%               call. Setting this to 0 is akin to making a promise that
%               U will not be used during FLAG=3. If you break the promise
%               then unpredictable results will occur.
%      SYS(7) = Number of sample times. This is the number of rows in TS.
%
%
%      X0     = Initial state conditions or [] if no states.
%
%      STR    = State ordering strings which is generally specified as [].
%
%      TS     = An m-by-2 matrix containing the sample time
%               (period, offset) information. Where m = number of sample
%               times. The ordering of the sample times must be:
%
%               TS = [0      0,      : Continuous sample time.
%                     0      1,      : Continuous, but fixed in minor step
%                                      sample time.
%                     PERIOD OFFSET, : Discrete sample time where
%                                      PERIOD > 0 & OFFSET < PERIOD.
%                     -2     0];     : Variable step discrete sample time
%                                      where FLAG=4 is used to get time of
%                                      next hit.
%
%               There can be more than one sample time providing
%               they are ordered such that they are monotonically
%               increasing. Only the needed sample times should be
%               specified in TS. When specifying than one
%               sample time, you must check for sample hits explicitly by
%               seeing if
%                  abs(round((T-OFFSET)/PERIOD) - (T-OFFSET)/PERIOD)
%               is within a specified tolerance, generally 1e-8. This
%               tolerance is dependent upon your model's sampling times
%               and simulation time.
%
%               You can also specify that the sample time of the S-function
%               is inherited from the driving block. For functions which
%               change during minor steps, this is done by
%               specifying SYS(7) = 1 and TS = [-1 0]. For functions which
%               are held during minor steps, this is done by specifying
%               SYS(7) = 1 and TS = [-1 1].

%   Copyright 1990-2002 The MathWorks, Inc.
%   $Revision: 1.18 $

%
% The following outlines the general structure of an S-function.
%
switch flag,

  %%%%%%%%%%%%%%%%%%
  % Initialization %
  %%%%%%%%%%%%%%%%%%
  case 0,
    [sys,x0,str,ts]=mdlInitializeSizes;

  %%%%%%%%%%%%%%%
  % Derivatives %
  %%%%%%%%%%%%%%%
  case 1,
    sys=mdlDerivatives(t,x,u);

  %%%%%%%%%%
  % Update %
  %%%%%%%%%%
  case 2,
    sys=mdlUpdate(t,x,u);

  %%%%%%%%%%%
  % Outputs %
  %%%%%%%%%%%
  case 3,
    sys=mdlOutputs(t,x,u);

  %%%%%%%%%%%%%%%%%%%%%%%
  % GetTimeOfNextVarHit %
  %%%%%%%%%%%%%%%%%%%%%%%
  case 4,
    sys=mdlGetTimeOfNextVarHit(t,x,u);

  %%%%%%%%%%%%%
  % Terminate %
  %%%%%%%%%%%%%
  case 9,
    sys=mdlTerminate(t,x,u);

  %%%%%%%%%%%%%%%%%%%%
  % Unexpected flags %
  %%%%%%%%%%%%%%%%%%%%
  otherwise
    error(['Unhandled flag = ',num2str(flag)]);

end

% end sfuntmpl

%
%=============================================================================
% mdlInitializeSizes
% Return the sizes, initial conditions, and sample times for the S-function.
%=============================================================================
%
function [sys,x0,str,ts]=mdlInitializeSizes

%
% call simsizes for a sizes structure, fill it in and convert it to a
% sizes array.
%
% Note that in this example, the values are hard coded.  This is not a
% recommended practice as the characteristics of the block are typically
% defined by the S-function parameters.
%
sizes = simsizes;

sizes.NumContStates  = 21;  % 
sizes.NumDiscStates  = 0;  % no discrete states
sizes.NumOutputs     = 21;  % 
sizes.NumInputs      = 15;  % 
sizes.DirFeedthrough = 0;  % leave this alone 
sizes.NumSampleTimes = 1;  % at least one sample time is needed

sys = simsizes(sizes);

%
% initialize the initial conditions
%
x0  = [0.7 1.4 1.4 0.3 0.8 0.4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0]; %art, ven,  other organs, uterus, legs, liver

%
% str is always an empty matrix
%
str = [];

%
% initialize the array of sample times
%
ts  = [0 0];

% end mdlInitializeSizes

%
%=============================================================================
% mdlDerivatives
% Return the derivatives for the continuous states.
%=============================================================================
%
function sys=mdlDerivatives(t,x,u)
%
%
% u=[1 1 1 90 0 0 0 0 0 1 1 1 1 100 0]
% x0  = [0.7 1.4 1.3 0.3 0.8 0.4 0 0 0 0 0 0]; %art, ven,  other organs, uterus, legs, liver
%u(1) preg on
%u(2) PP on/return to baseline
%u(3) preg off
MAP = u(4); %Mean arterial pressure
S = u(5)*60*24; % Source: L/min -> L/day
E = u(6)*60*24; % Elimination: L/min -> L/day
%E=E + del_V_Org*u(3)/PP;
DEL = u(7); %on/off delivery
CON = u(8); %on/off contraction
H = u(9);%*24*60; %on/off hemorrhage(t)

T = u(10)./100; %uterine tone, fractional
Alpha = u(11); %Activation coefficient
De = u(12); % Deactivation coefficient

%Hemorrhage, Delivery, Blood Flow out, Contraction:
H_t= H.*25.*(1-T); %H_t=10000/T*exp(-(H-60).^2.*1/(60.1-60*T));
D_t= DEL.*30.*(1-0.5*T);
BF_loss= D_t + H_t; %+ H_t/24/60;%Blood loss
C =CON.*6./(1-0.75*T);%.*(x(4)-0.35/T)./(0.35/T)  CON.*8./(1-0.8*T)+


%Volumes:
%V_HL= x(1);
V_A = x(1);
V_V = x(2);
V_U = x(4);
V_Org = x(3);
V_Leg = x(5);
V_Liv = x(6);

%Delta (and Total) Volumes:
del_V_A = V_A -0.7;
del_V_V = V_V -1.4;
del_V_U = V_U -0.3;
del_V_Org = V_Org -1.3;
del_V_Leg = V_Leg -0.8;
del_V_Liv = V_Liv -0.4;
V_tot = V_A + V_V + V_Org + V_U + V_Leg + V_Liv;
del_V=V_tot - 4.9;

%Cardiac output:
CO=(del_V + 4.9)*60*24; %L/min -> L/day

%Number of days in postpartum period:
PP=28;

%Resistance changes:
delR_V = 1 + 0/60/24/270*u(1) - 0/60/24/270*u(2) - del_V_V/60/24/PP*u(3);
delR_A= 1 + 0.02/60/24/270*u(1) - 0.02/60/24/270*u(2) - del_V_A/60/24/PP*u(3);
delR_Org = 1 + 0.001/60/24/270*u(1) - 0.001/60/24/270*u(2) - del_V_Org/60/24/PP*u(3);
delR_U = 1 + 0.75/60/24/270*u(1) - 0.75/60/24/270*u(2) - del_V_U/60/24/PP*u(3);
delR_Leg = 1 + 0.3/60/24/270*u(1) - 0.3/60/24/270*u(2) - del_V_Leg/60/24/PP*u(3);
delR_Liv = 1 + 0.03/60/24/270*u(1) - 0.03/60/24/270*u(2) - del_V_Liv/60/24/PP*u(3);

%Fraction of flows as divided CO:
f_U = 0.04 + u(13) + (BF_loss-C)/CO*T;% + (BF_loss-C)/CO*(del_V_U)T;
f_Leg = 0.02 + u(14);
f_Liv = 0.05 + u(15);
f_Org = 1 - f_U - f_Leg - f_Liv;

%MAPi= 90; %mm HG
%MVPi= 5; %mm HG
P_VPo= 8/3*del_V + 2; %mm HG
P_RAP=P_VPo;
P_AP=MAP*1.3; 
%R_circ=(P_AP-P_VPo)/CO;

%Fractions:
% F_Orgi = V_Org/(V_Org+V_Leg+V_Liv+V_U)*CO;%V_Org/V_tot*CO;%mm HG - 3
% F_Legi = V_Leg/(V_Org+V_Leg+V_Liv+V_U)*CO;%V_Leg/V_tot*CO;%
% F_Livi = V_Liv/(V_Org+V_Leg+V_Liv+V_U)*CO;%V_Liv/V_tot*CO;%
% F_Ui   = V_U/(V_Org+V_Leg+V_Liv+V_U)*CO;%V_U/V_tot*CO;%

%Flow into organs:
F_Orgi = f_Org*CO;%
F_Legi = f_Leg*CO;%
F_Livi = f_Liv*CO;%
F_Ui   = f_U*CO;%

%Pressure drop ratio: 
in=3.6;
out=2;

%Pressure into organs
P_Ui = P_AP/in; %*V_U/V_tot;%- (BF_loss/V_U/1000);%(1+H_t/24/60));%V_U/300);
P_Legi = P_AP/in; %*V_Leg/V_tot;
P_Livi = P_AP/in; %*V_Liv/V_tot;
P_Orgi = P_AP/in; %mm HG - 3

%Pressure out of organs
P_Orgo = P_RAP*out;%*V_Org/V_tot;%mm HG - 3
P_Lego = P_RAP*out;%*V_Leg/V_tot;%
P_Livo = P_RAP*out;%*V_Liv/V_tot;%
P_Uo   = P_RAP*(1-(BF_loss-C)/F_Ui)*out;%*V_U/V_tot;%
%P_uo = P_ui/out*(1-BF_loss/CO);%

%P_orgo = P_orgi/out; %*(1-del_V_Org/del_V); %(out*V_Org/V_tot); %mm HG - 3
%P_uo = P_ui/out*(1-BF_loss/CO);%*(1-del_V_U/del_V); %(out*V_U/V_tot);
%P_lego = P_legi/out;%*(1-del_V_Leg/del_V); %(out*V_Leg/V_tot);
%P_livo = P_livi/out;%*(1-del_V_Liv/del_V); %(out*V_Liv/V_tot);

%Resistances
%R_HL = (MAPi - MVPi)/CO;%Heart/Lungs
R_Org = (P_Orgi - P_Orgo)/F_Orgi*(delR_Org);%R_Org;%(P_orgi - P_orgo)/CO;%R_Org;%Organs
R_Leg = (P_Legi - P_Lego)/F_Legi*(delR_Leg);%Liv
R_Liv = (P_Livi - P_Livo)/F_Livi*(delR_Liv);%Liv
R_U = (P_Ui - P_Uo)/(F_Ui)*(delR_U + 0.000001*(100-u(10))/100);% - (CON+H)*T*10*(V_U-0.35)/F_Ui );
%+ 0.5.*CON.*(V_U - 0.35./T)./CO;%Uterus, w/ tone dependence + (P_ui - P_uo)/CO*DEL*(1-T)/500;
%R_D_H = (H+DEL)*(P_Ui)/(F_Ui)*(delR_U + 0.00000005*(100-u(8))/100);%Uterus, w/ tone dependence + (P_ui - P_uo)/CO*DEL*(1-T)/500;
%R_C = u(9).*(P_AP - P_Uo)/(CO)*(delR_U + 0.00000005*(100-u(8))/100);%

%Arterial and Venous Resistances
R_A = (P_AP-P_Orgi)/CO*(delR_A);%Arterial
R_V= ((P_Orgo*F_Orgi + P_Uo*F_Ui + P_Lego*F_Legi + P_Livo*F_Livi)/CO - P_VPo)/CO*(delR_V) + (V_V - 1.4)*0.03/CO;
%((P_Orgo + P_Uo + P_Lego + P_Livo)/4 - P_VPo)/CO*(delR_V) + (V_V - 1.4)*0.03/CO; %Venous  
%R_V = R_circ - R_Org*R_U*R_Leg*R_Liv/(R_Org+R_U+R_Leg+R_Liv) - R_A;
 
%Other Resistances & Flows: (Not used)
%R_D_H = (H+DEL)*(P_ui-P_uo)/(BF_loss);
%R_U_T =R_U+R_D_H;
%R_T = R_A + R_Org*R_U_T*R_Leg*R_Liv/(R_Org+R_U_T+R_Leg+R_Liv) + R_V;
%P_uo = P_uo - R_U_T*(CO-BF_loss);
%BF_loss=(P_Ui)/R_D_H;
%C=(P_AP-P_Uo)/R_C;

%Redefined flow in and out:
F_Vi=((P_Orgo*F_Orgi + P_Uo*F_Ui + P_Lego*F_Legi + P_Livo*F_Livi)/CO - P_VPo)/R_V;
F_Vo=CO;
F_Ai=CO;
F_Ao=(P_AP-P_Orgi)/R_A;

F_Orgo= (P_Orgi - P_Orgo)/R_Org;
F_Uo= (P_Ui - P_Uo)/R_U;
F_Lego= (P_Legi - P_Lego)/R_Leg;
F_Livo= (P_Livi - P_Livo)/R_Liv;

%F=[F_Ai F_Ao 0 F_Vi F_Vo C F_Orgi F_Orgo S-E F_Ui F_Uo -BF_loss-C F_Legi F_Lego 0 F_Livi F_Livo 0];

%Volumetric ODEs:
%xdot(1,:) = (P_V - P_HL)/R_HL - (P_HL - P_A)/R_A; %Heart/Lungs
xdot(1,:) = F_Ai - F_Ao;% - (P_AP - P_ui)/R_U - (P_AP - P_legi)/R_Leg + (P_AP - P_livi)/R_Leg; % Art - (MAP - MVPi)/R_A
xdot(3,:) = F_Orgi - F_Orgo + S - E;%;% Organs - (P_orgo - MVPi)/R_V;% 
xdot(4,:) = F_Ui - F_Uo - BF_loss - C;%U
xdot(5,:) = F_Legi - F_Lego;%Leg
xdot(6,:) = F_Livi - F_Livo;%Liv
xdot(2,:) = F_Vi - F_Vo + C;
%xdot(7,:) = F_Lungi

% (P_livi - P_livo)/R_Liv + (P_legi - P_lego)/R_Leg + (P_ui - P_uo)/R_U + (P_orgi - P_orgo)/R_Org - (P_AP - P_VPo)/R_circ; %Ven
% (P_orgo + P_uo + P_lego + P_livo - P_VPo)/R_V - CO + C;
% - (MVPi - MAP)/R_A
%+ (P_uo - P_VPo)/R_V + (P_lego - P_VPo)/R_V + (P_livo - P_VPo)/R_V 


%Concentrations
C_A = x(7);
C_V = x(8);
C_U = x(10);
C_Org = x(9);
C_Leg = x(11);
C_Liv = x(12);

%Special Equations:
%r_hem = (2./(1+exp(T./43.5295))).*0.5./30.*BF_Hem;
A = Alpha.*(BF_loss);
D=De;
Res=1;
%F_orgi=(P_AP - P_orgi)/R_A*C_A/V_A
%F_ui=(P_AP - P_ui)/R_A*C_A/V_A
%F_legi=(P_AP - P_legi)/R_A*C_A/V_A
%F_livi=(P_AP - P_livi)/R_A*C_A/V_A
%F_in

%Concentration ODEs:
xdot(7,:) = CO*C_V/Res/V_A - (P_AP-P_Orgi)/R_A*C_A/V_A - D*C_A/V_A - C_A./V_A.*xdot(1,:); %Art
xdot(8,:) = ((P_Orgo*F_Orgi*C_Org/V_V + P_Uo*(F_Ui-BF_loss+C)*C_U/Res/V_V + P_Lego*F_Legi*C_Leg/Res/V_V + P_Livo*F_Livi*C_Liv/V_V)/CO - P_VPo*C_V/Res/V_V)/R_V + C/Res*C_U/V_V - CO*C_V/Res/V_V  - D*C_V/V_V - C_V/V_V*xdot(2,:); %Ven
xdot(9,:) = F_Orgi*C_A/V_Org - (P_Orgi - P_Orgo)/R_Org*C_Org/V_Org - D*C_Org/V_Org - C_Org/V_Org*xdot(3,:) ;%;% Organs
xdot(10,:) = F_Ui*C_A/V_U + A/V_U - (P_Ui - P_Uo)/R_U*C_U/Res/V_U - C/Res*C_U/V_U - BF_loss*C_U/V_U - D*C_U/V_U - C_U/V_U*xdot(4,:) ;% Uterus
xdot(11,:) = F_Legi*C_A/V_Leg - (P_Legi - P_Lego)/R_Leg*C_Leg/Res/V_Leg - D*C_Leg/V_Leg - C_Leg/V_Leg*xdot(5,:) ;% Leg
xdot(12,:) = F_Livi*C_A/V_Liv - (P_Livi - P_Livo)/R_Liv*C_Liv/V_Liv - D*90*C_Liv/V_Liv - C_Liv/V_Liv*xdot(6,:) ;% Liv

%Tracked Volume Changes:
xdot(13,:) = C; %contraction
xdot(14,:) = D_t; %delivery loss
xdot(15,:) = H_t; %hemorrhage

%Clot State - K
K_A = x(16);
K_V = x(17);
K_U = x(18);
K_Org = x(19);
K_Leg = x(20);
K_Liv = x(21);

Per=20;
Mid=30;
Cent=40;
Bind_Leg=1000;
Bind_U=5000;
Bind_A=500;
Bind_V=1000;
Bind_Org=500;
Bind_Liv=500;

%dKl/dt = f (residence time * Ci) - k * Ki
xdot(16,:) = Bind_A*V_A/F_Ai*C_A/(1 + C_A)- K_A*Cent; %Art
xdot(17,:) = Bind_V*V_V/F_Vi*C_V/(1 + C_V)- K_V*Cent; %Ven
xdot(18,:) = Bind_U*V_U/F_Ui*C_U/(1 + C_U)- K_U*Mid; %Uterus
xdot(19,:) = Bind_Org*V_Org/F_Orgi*C_Org/(1 + C_Org)- K_Org*Mid; %Org
xdot(20,:) = Bind_Leg*V_Leg/F_Legi*C_Leg/(1 + C_Leg)- K_Leg*Per; %Leg
xdot(21,:) = Bind_Liv*V_Liv/F_Livi*C_Liv/(1 + C_Liv)- K_Liv*Mid; %Liv

%2 comparment model ODEs:
%xdot(1,:) = Q * (kuv*Vu - kvu*Vv) - FE; %vasculature
%xdot(2,:) = Q * (kvu*Vv - kuv*Vu) - Fdel - Fhem; %uterine
%xdot(3,:) = Q * (Cu-Cv)./Vv - D./Vv - Cv./Vv.*xdot(1,:); %vasculature
%xdot(4,:) = Q * (Cv-Cu)./Vu + A./Vu - Cu./Vu.*xdot(2,:) - Cu./Vu*(Fhem+Fdel); %uterine% - D./Vv;

sys = [xdot];

% end mdlDerivatives

%
%=============================================================================
% mdlUpdate
% Handle discrete state updates, sample time hits, and major time step
% requirements.
%=============================================================================
%
function sys=mdlUpdate(t,x,u)

sys = [];

% end mdlUpdate

%
%=============================================================================
% mdlOutputs
% Return the block outputs.
%=============================================================================
%
function sys=mdlOutputs(t,x,u)

sys = [x(1) x(2) x(3) x(4) x(5) x(6) x(7) x(8) x(9) x(10) x(11) x(12) x(13) x(14) x(15) x(16) x(17) x(18) x(19) x(20) x(21)];

% end mdlOutputs

%
%=============================================================================
% mdlGetTimeOfNextVarHit
% Return the time of the next hit for this block.  Note that the result is
% absolute time.  Note that this function is only used when you specify a
% variable discrete-time sample time [-2 0] in the sample time array in
% mdlInitializeSizes.
%=============================================================================
%
function sys=mdlGetTimeOfNextVarHit(t,x,u)

sampleTime = 1;    %  Example, set the next hit to be one second later.
sys = t + sampleTime;

% end mdlGetTimeOfNextVarHit

%
%=============================================================================
% mdlTerminate
% Perform any end of simulation tasks.
%=============================================================================
%
function sys=mdlTerminate(t,x,u)

sys = [];

% end mdlTerminate
