# PBPK
Files of Physiologically Based PharmacoKinetic (PBPK) model of pregnancy
