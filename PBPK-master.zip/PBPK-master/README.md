# PBPK
Matlab files (block diagram, s-function, script) for simulating and plotting results of Physiologically Based PharmacoKinetic (PBPK) model of pregnancy. This model includes lungs, arteries, liver, uterus, legs, organs, and veins. 

This covers volumetric changes, activation of clotting factors, and formation of a clot state.
