% %% CO 
% figure(1)
% plot([0,2,4,6],[2,5,8,9],'k','LineWidth',1.5)
% hold on
% plot(2,5,'-o','MarkerFaceColor','b','MarkerSize',12)
% hold on
% plot(2+4/3,7,'-o','MarkerFaceColor','m','MarkerSize',12)
% %legend('baseline','pregnancy')
% hold off
% text(2,5.75,'\Delta V_{tot} = 2','Rotation',34,'Color','k','FontSize',16)%,'FontWeight','bold'
% text(1.7,4.05,'Baseline','Rotation',34,'Color','b','FontSize',14)%
% text(3,6,'Pregnancy','Rotation',34,'Color','m','FontSize',14)%
% axis([0 6 0 10])
% ylabel('CO (L/min)');
% xlabel('RAP-Venous Return Pressure (mm HG)');
% set(gca,'FontWeight','bold','LineWidth',2.5,'FontSize',18)
% 
% R=tp448a31a9_b468_4ed3_a980_039512a46a49.R;
% tout=tp448a31a9_b468_4ed3_a980_039512a46a49.tout;
% 
% figure(2)
% plot(tout,R(:,1),'r','LineWidth',2);
% hold on
% plot(tout,R(:,2),'b','LineWidth',2);
% hold on
% plot(tout,R(:,3),'k','LineWidth',2);
% hold on
% plot(tout,R(:,5),'Color',[0.75, 0.75 0.75],'LineWidth',2);
% hold on
% plot(tout,R(:,6),'Color',[0.90, 0.60, 0.10],'LineWidth',2);
% hold on
% plot(tout,R(:,4),'Color',[0.8, 0, 0.75],'LineWidth',2);
% hold off
% %ylabel('Volume (L)');
% xlabel('Time (day)');
% legend('A','V','Org','Legs','Liv','U')
% axis([0 280 0.999999 1.0000005])
% title('Resistance Inputs')
% set(gca,'FontWeight','bold','LineWidth',2.5,'FontSize',16)

%% PBPK Script

C_V=tp448a31a9_b468_4ed3_a980_039512a46a49.C_V;
R=tp448a31a9_b468_4ed3_a980_039512a46a49.R;
FF=tp448a31a9_b468_4ed3_a980_039512a46a49.FracFlow;
tout=tp448a31a9_b468_4ed3_a980_039512a46a49.tout;
tout_min=tout*24*60-(280*24*60);
tout_hour=tout*24-(280*24);

C_V_tot= C_V(:,3) + C_V(:,2) + C_V(:,1) + C_V(:,4) + C_V(:,5) + C_V(:,6);
FF(:,1)=0.04+FF(:,1);
FF(:,2)=0.02+FF(:,2);
FF(:,3)=0.05+FF(:,3);
FF(:,4)=1-FF(:,1)-FF(:,2)-FF(:,3);%organs
CO=C_V_tot;

% figure(1)
% plot(tout,FF(:,1),'Color',[0.8, 0, 0.75],'LineWidth',2)
% hold on
% plot(tout,FF(:,2),'Color',[0.75, 0.75 0.75],'LineWidth',2)
% hold on
% plot(tout,FF(:,3),'Color',[0.90, 0.60, 0.10],'LineWidth',2)
% hold on
% plot(tout,FF(:,4),'k','LineWidth',2);
% hold off
% ylabel('Fraction of CO');
% xlabel('Time (day)');
% legend('U','Legs','Liv','Org','Location','north')
% axis([0 320 0 1])
% set(gca,'FontWeight','bold','LineWidth',2.5,'FontSize',16)

figure(1)
plot(tout,FF(:,1).*CO,'Color',[0.8, 0, 0.75],'LineWidth',2)
hold on
plot(tout,FF(:,2).*CO,'Color',[0.75, 0.75 0.75],'LineWidth',2)
hold on
plot(tout,FF(:,3).*CO,'Color',[0.90, 0.60, 0.10],'LineWidth',2)
hold on
plot(tout,FF(:,4).*CO,'k','LineWidth',2);
hold off
ylabel('Flowrate In (L/min)');
xlabel('Time (day)');
legend('U','Legs','Liv','Org','Location','north')
axis([0 320 0 6])
set(gca,'FontWeight','bold','LineWidth',2.5,'FontSize',16)

figure(2)
plot(tout,C_V(:,4)./(FF(:,1).*CO),'Color',[0.8, 0, 0.75],'LineWidth',2)
hold on
plot(tout,C_V(:,5)./(FF(:,2).*CO),'Color',[0.75, 0.75 0.75],'LineWidth',2)
hold on
plot(tout,C_V(:,6)./(FF(:,3).*CO),'Color',[0.90, 0.60, 0.10],'LineWidth',2)
hold on
plot(tout,C_V(:,3)./(FF(:,4).*CO),'k','LineWidth',2);
hold off
ylabel('Volume/Flow In (min)');
xlabel('Time (day)');
legend('U','Legs','Liv','Org','Location','north')
axis([0 320 0 10])
set(gca,'FontWeight','bold','LineWidth',2.5,'FontSize',16)

figure(3)
plot(tout,C_V(:,1),'r','LineWidth',2);
hold on
plot(tout,C_V(:,2),'b','LineWidth',2);
hold on
plot(tout,C_V(:,3),'k','LineWidth',2);
hold on
plot(tout,C_V(:,5),'Color',[0.75, 0.75 0.75],'LineWidth',2);
hold on
plot(tout,C_V(:,6),'Color',[0.90, 0.60, 0.10],'LineWidth',2);
hold on
plot(tout,C_V(:,4),'Color',[0.8, 0, 0.75],'LineWidth',2);
hold on
plot(tout,C_V_tot,'k-.','LineWidth',2);
hold off
ylabel('Volume (L)');
xlabel('Time (day)');
legend('A','V','Org','Legs','Liv','U','Tot','Location','north')
axis([0 320 0 10])
set(gca,'FontWeight','bold','LineWidth',2.5,'FontSize',16)

figure(4)
plot(tout_min,C_V(:,1),'r','LineWidth',2);
hold on
plot(tout_min,C_V(:,2),'b','LineWidth',2);
hold on
plot(tout_min,C_V(:,3),'k','LineWidth',2);
hold on
plot(tout_min,C_V(:,5),'Color',[0.75, 0.75 0.75],'LineWidth',2);
hold on
plot(tout_min,C_V(:,6),'Color',[0.90, 0.60, 0.10],'LineWidth',2);
hold on
plot(tout_min,C_V(:,4),'Color',[0.8, 0, 0.75],'LineWidth',2);
hold on
plot(tout_min,C_V_tot,'k-.','LineWidth',2);
hold off
ylabel('Volume (L)');
xlabel('Time (min)');
legend('A','V','Org','Legs','Liv','U','Tot','Location','best')
axis([-30 120 0 8])
set(gca,'FontWeight','bold','LineWidth',2.5,'FontSize',16)


figure(5)
plot(tout,C_V(:,7),'r','LineWidth',2);
hold on
plot(tout,C_V(:,8),'b','LineWidth',2);
hold on
plot(tout,C_V(:,9),'k','LineWidth',2);
hold on
plot(tout,C_V(:,11),'Color',[0.75, 0.75 0.75],'LineWidth',2);
hold on
plot(tout,C_V(:,12),'Color',[0.90, 0.60, 0.10],'LineWidth',2);
hold on
plot(tout,C_V(:,10),'Color',[0.8, 0, 0.75],'LineWidth',2);
hold off
ylabel('Concentration (CF/L)');
xlabel('Time (day)');
legend('A','V','Org','Legs','Liv','U')
axis([270 320 0 20])
set(gca,'FontWeight','bold','LineWidth',2.5,'FontSize',16)

figure(6)
plot(tout_min,C_V(:,7),'r','LineWidth',2.5);
hold on
plot(tout_min,C_V(:,8),'b','LineWidth',1.5);
hold on
plot(tout_min,C_V(:,9),'k','LineWidth',2.5);
hold on
plot(tout_min,C_V(:,11),'Color',[0.75, 0.75 0.75],'LineWidth',2);
hold on
plot(tout_min,C_V(:,12),'Color',[0.90, 0.60, 0.10],'LineWidth',1.5);
hold on
plot(tout_min,C_V(:,10),'Color',[0.8, 0, 0.75],'LineWidth',2.5);
hold off
ylabel('Concentration (aCF/L)');
xlabel('Time (min since delivery)');
legend('Art','Ven','Org','Legs','Liv','U','Location','northwest')
axis([-30 180 0 20])
set(gca,'FontWeight','bold','LineWidth',2.5,'FontSize',16)

figure(7)
plot(tout_min,C_V(:,7).*C_V(:,1),'r','LineWidth',2);
hold on
plot(tout_min,C_V(:,8).*C_V(:,2),'b','LineWidth',2);
hold on
plot(tout_min,C_V(:,9).*C_V(:,3),'k','LineWidth',2);
hold on
plot(tout_min,C_V(:,11).*C_V(:,5),'Color',[0.75, 0.75 0.75],'LineWidth',2);
hold on
plot(tout_min,C_V(:,12).*C_V(:,6),'Color',[0.90, 0.60, 0.10],'LineWidth',2);
hold on
plot(tout_min,C_V(:,10).*C_V(:,4),'Color',[0.8, 0, 0.75],'LineWidth',2);
hold on
plot(tout_min,(C_V(:,7).*C_V(:,1) + C_V(:,8).*C_V(:,2) + C_V(:,9).*C_V(:,3) + C_V(:,11).*C_V(:,5) + C_V(:,12).*C_V(:,6) + C_V(:,10).*C_V(:,4)),'k-.','LineWidth',2)
hold off
ylabel('Mass (CF)');
xlabel('Time (day)');
legend('A','V','Org','Legs','Liv','U','Tot')
axis([-20 120 0 50])
set(gca,'FontWeight','bold','LineWidth',2.5,'FontSize',16)

figure(8)
plot(tout_min,-C_V(:,13),'LineWidth',2.75);
hold on
plot(tout_min,-C_V(:,14),'m','LineWidth',2.75);
hold on
plot(tout_min,-C_V(:,15),'r','LineWidth',2.75);
hold on
plot(tout_min,-(C_V(:,14) + C_V(:,15)),'k--','LineWidth',1.75);
hold on
plot(tout_min,-(C_V(:,14) + C_V(:,15) + C_V(:,13)),'k','LineWidth',1.75);
hold off
ylabel('Volume Change to Uterus (L)');
xlabel('Time (minutes since delivery)');
legend('Dynamic Contraction (C)','Delivery (D)','Hemorrhage (H)','D + H','D + H + C')
axis([-30 120 -1 1.5])%([-30 120 -0.05 1.5])
set(gca,'FontWeight','bold','LineWidth',2.5,'FontSize',16)


figure(9)
plot(tout_hour,C_V(:,16),'r','LineWidth',2);
hold on
plot(tout_hour,C_V(:,17),'b','LineWidth',2);
hold on
plot(tout_hour,C_V(:,19),'k','LineWidth',2);
hold on
plot(tout_hour,C_V(:,20),'Color',[0.75, 0.75 0.75],'LineWidth',2);
hold on
plot(tout_hour,C_V(:,21),'Color',[0.90, 0.60, 0.10],'LineWidth',2);
hold on
plot(tout_hour,C_V(:,18),'Color',[0.8, 0, 0.75],'LineWidth',2);
hold off
ylabel('Clot State (K)');
xlabel('Time (hour since delivery)');
legend('A','V','Org','Legs','Liv','U')
axis([-0.5 12 0 0.5])
set(gca,'FontWeight','bold','LineWidth',2.5,'FontSize',16)

figure(10)
plot(tout_hour,C_V(:,7),'r','LineWidth',2.5);
hold on
plot(tout_hour,C_V(:,8),'b','LineWidth',1.5);
hold on
plot(tout_hour,C_V(:,9),'k','LineWidth',2.5);
hold on
plot(tout_hour,C_V(:,11),'Color',[0.75, 0.75 0.75],'LineWidth',2);
hold on
plot(tout_hour,C_V(:,12),'Color',[0.90, 0.60, 0.10],'LineWidth',1.5);
hold on
plot(tout_hour,C_V(:,10),'Color',[0.8, 0, 0.75],'LineWidth',2.5);
hold off
ylabel('Concentration (aCF/L)');
xlabel('Time (hour since delivery)');
legend('Art','Ven','Org','Legs','Liv','U','Location','northeast')
axis([-0.5 12 0 15])
set(gca,'FontWeight','bold','LineWidth',2.5,'FontSize',16)

%% Blood Flow


%% Area
% Concentration
% C_A = x(7);
% C_V = x(8);
% C_U = x(10);
% C_Org = x(9);
% C_Leg = x(11);
% C_Liv = x(12);
% Volumes
% V_A = x(1);
% V_V = x(2);
% V_U = x(4);
% V_Org = x(3);
% V_Leg = x(5);
% V_Liv = x(6);


%Normal T=100
% tout_min_100 = tout_min
% exp_A = trapz(tout_min, C_V(:,7).*C_V(:,1))
% exp_V = trapz(tout_min, C_V(:,8).*C_V(:,2))
% exp_U = trapz(tout_min, C_V(:,10).*C_V(:,4))
% exp_Org = trapz(tout_min, C_V(:,9).*C_V(:,3))
% exp_Leg = trapz(tout_min, C_V(:,11).*C_V(:,5))
% exp_Liv = trapz(tout_min, C_V(:,12).*C_V(:,6))
% exp_t_A = cumsum(C_V(:,7).*C_V(:,1))
% exp_t_V = cumsum(C_V(:,8).*C_V(:,2))
% exp_t_U = cumsum(C_V(:,10).*C_V(:,4))
% exp_t_Org = cumsum(C_V(:,9).*C_V(:,3))
% exp_t_Leg = cumsum(C_V(:,11).*C_V(:,5))
% exp_t_Liv = cumsum(C_V(:,12).*C_V(:,6))

%Diminished T=60
% tout_min_60 = tout_min
% exp_A_60 = trapz(tout_min, C_V(:,7).*C_V(:,1))
% exp_V_60 = trapz(tout_min, C_V(:,8).*C_V(:,2))
% exp_U_60 = trapz(tout_min, C_V(:,10).*C_V(:,4))
% exp_Org_60 = trapz(tout_min, C_V(:,9).*C_V(:,3))
% exp_Leg_60 = trapz(tout_min, C_V(:,11).*C_V(:,5))
% exp_Liv_60 = trapz(tout_min, C_V(:,12).*C_V(:,6))
% exp_t_A_60 = cumsum(C_V(:,7).*C_V(:,1))
% exp_t_V_60 = cumsum(C_V(:,8).*C_V(:,2))
% exp_t_U_60 = cumsum(C_V(:,10).*C_V(:,4))
% exp_t_Org_60 = cumsum(C_V(:,9).*C_V(:,3))
% exp_t_Leg_60 = cumsum(C_V(:,11).*C_V(:,5))
% exp_t_Liv_60 = cumsum(C_V(:,12).*C_V(:,6))

%Severly Diminished T=10
% tout_min_10 = tout_min
% exp_A_10 = trapz(tout_min, C_V(:,7).*C_V(:,1))
% exp_V_10 = trapz(tout_min, C_V(:,8).*C_V(:,2))
% exp_U_10 = trapz(tout_min, C_V(:,10).*C_V(:,4))
% exp_Org_10 = trapz(tout_min, C_V(:,9).*C_V(:,3))
% exp_Leg_10 = trapz(tout_min, C_V(:,11).*C_V(:,5))
% exp_Liv_10 = trapz(tout_min, C_V(:,12).*C_V(:,6))
% exp_t_A_10 = cumsum(C_V(:,7).*C_V(:,1))
% exp_t_V_10 = cumsum(C_V(:,8).*C_V(:,2))
% exp_t_U_10 = cumsum(C_V(:,10).*C_V(:,4))
% exp_t_Org_10 = cumsum(C_V(:,9).*C_V(:,3))
% exp_t_Leg_10 = cumsum(C_V(:,11).*C_V(:,5))
% exp_t_Liv_10 = cumsum(C_V(:,12).*C_V(:,6))


%%
% figure(8)
% b = bar([exp_A exp_V exp_U exp_Org exp_Leg exp_Liv;...
%     exp_A_60 exp_V_60 exp_U_60 exp_Org_60 exp_Leg_60 exp_Liv_60;...
%     exp_A_10 exp_V_10 exp_U_10 exp_Org_10 exp_Leg_10 exp_Liv_10]);
% b(1).FaceColor = 'r';
% b(2).FaceColor = 'b';
% b(3).FaceColor = [0.8, 0, 0.75];
% b(4).FaceColor = 'k';
% b(5).FaceColor = [0.75, 0.75 0.75];
% b(6).FaceColor = [0.90, 0.60, 0.10];
% %'color',{'r','b',[0.8, 0, 0.75],'k',[0.75, 0.75 0.75],[0.90, 0.60, 0.10]})
% xticks(1:6)
% xticklabels({'T=100','T=60','T=10'})
% ylabel('Exposure (CF)')
% xlabel('Uterine Tone')
% legend({'Art','Ven','U','Org','Leg','Liv'},'Location','northwest')
% set(gca,'FontWeight','bold','LineWidth',2,'FontSize',16)
% 
% figure(9)
% subplot(1,3,1)
% plot(tout_min_100,exp_t_A,'r','LineWidth',2.5);
% hold on
% plot(tout_min_100,exp_t_V,'b','LineWidth',1.5);
% hold on
% plot(tout_min_100,exp_t_Org,'k','LineWidth',2.5);
% hold on
% plot(tout_min_100,exp_t_Leg,'Color',[0.75, 0.75 0.75],'LineWidth',1.5);
% hold on
% plot(tout_min_100,exp_t_Liv,'Color',[0.90, 0.60, 0.10],'LineWidth',1.5);
% hold on
% plot(tout_min_100,exp_t_U,'Color',[0.8, 0, 0.75],'LineWidth',2.5);
% hold off
% ylabel('Concentration (CF/L)');
% xlabel('Time (min since delivery)');
% legend('Art','Ven','Org','Legs','Liv','U','Location','northwest')
% axis([-30 200 0 1000])
% set(gca,'FontWeight','bold','LineWidth',2.5,'FontSize',16)
% 
% subplot(1,3,2)
% plot(tout_min_60,exp_t_A_60,'r','LineWidth',2.5);
% hold on
% plot(tout_min_60,exp_t_V_60,'b','LineWidth',1.5);
% hold on
% plot(tout_min_60,exp_t_Org_60,'k','LineWidth',2.5);
% hold on
% plot(tout_min_60,exp_t_Leg_60,'Color',[0.75, 0.75 0.75],'LineWidth',1.5);
% hold on
% plot(tout_min_60,exp_t_Liv_60,'Color',[0.90, 0.60, 0.10],'LineWidth',1.5);
% hold on
% plot(tout_min_60,exp_t_U_60,'Color',[0.8, 0, 0.75],'LineWidth',2.5);
% hold off
% ylabel('Concentration (CF/L)');
% xlabel('Time (min since delivery)');
% legend('Art','Ven','Org','Legs','Liv','U','Location','northwest')
% axis([-30 200 0 1000])
% set(gca,'FontWeight','bold','LineWidth',2.5,'FontSize',16)
% 
% subplot(1,3,3)
% plot(tout_min_10,exp_t_A_10,'r','LineWidth',2.5);
% hold on
% plot(tout_min_10,exp_t_V_10,'b','LineWidth',1.5);
% hold on
% plot(tout_min_10,exp_t_Org_10,'k','LineWidth',2.5);
% hold on
% plot(tout_min_10,exp_t_Leg_10,'Color',[0.75, 0.75 0.75],'LineWidth',1.5);
% hold on
% plot(tout_min_10,exp_t_Liv_10,'Color',[0.90, 0.60, 0.10],'LineWidth',1.5);
% hold on
% plot(tout_min_10,exp_t_U_10,'Color',[0.8, 0, 0.75],'LineWidth',2.5);
% hold off
% ylabel('Concentration (CF/L)');
% xlabel('Time (min since delivery)');
% legend('Art','Ven','Org','Legs','Liv','U','Location','northwest')
% axis([-30 200 0 1000])
% set(gca,'FontWeight','bold','LineWidth',2.5,'FontSize',16)
